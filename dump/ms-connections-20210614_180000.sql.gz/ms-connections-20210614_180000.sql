--
-- PostgreSQL database dump
--

-- Dumped from database version 11.10
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: localized(json, text); Type: FUNCTION; Schema: public; Owner: root
--

CREATE FUNCTION public.localized(obj json, lang text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    BEGIN
        RETURN CASE
            WHEN obj->>lang IS NOT NULL
                THEN obj->>lang
            WHEN obj->>'en' IS NOT NULL
                THEN obj->>'en'
            WHEN obj->>'ru' IS NOT NULL
                THEN obj->>'ru'
            END;
    END;
$$;


ALTER FUNCTION public.localized(obj json, lang text) OWNER TO root;

SET default_tablespace = '';

--
-- Name: company_connections; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.company_connections (
    id integer NOT NULL,
    customer character varying NOT NULL,
    vendor character varying NOT NULL,
    status character varying,
    message text,
    reason text,
    change_status_date bigint,
    change_status_company character varying,
    change_status_user integer
);


ALTER TABLE public.company_connections OWNER TO root;

--
-- Name: company_connections_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.company_connections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_connections_id_seq OWNER TO root;

--
-- Name: company_connections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.company_connections_id_seq OWNED BY public.company_connections.id;


--
-- Name: company_connections_versions; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.company_connections_versions (
    id integer NOT NULL,
    connection_id integer NOT NULL,
    time_stamp bigint NOT NULL,
    data json NOT NULL
);


ALTER TABLE public.company_connections_versions OWNER TO root;

--
-- Name: company_connections_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.company_connections_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_connections_versions_id_seq OWNER TO root;

--
-- Name: company_connections_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.company_connections_versions_id_seq OWNED BY public.company_connections_versions.id;


--
-- Name: connections; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.connections (
    id integer NOT NULL,
    type character varying NOT NULL,
    object integer NOT NULL,
    sender character varying NOT NULL,
    recipient character varying NOT NULL,
    status character varying NOT NULL,
    comment text,
    reject_reason text,
    create_date bigint NOT NULL,
    create_user integer NOT NULL,
    create_company character varying NOT NULL,
    processing_date bigint,
    processing_user integer,
    processing_company character varying
);


ALTER TABLE public.connections OWNER TO root;

--
-- Name: connections_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.connections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.connections_id_seq OWNER TO root;

--
-- Name: connections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.connections_id_seq OWNED BY public.connections.id;


--
-- Name: connections_versions; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.connections_versions (
    id integer NOT NULL,
    connection_id integer NOT NULL,
    time_stamp bigint NOT NULL,
    data json NOT NULL
);


ALTER TABLE public.connections_versions OWNER TO root;

--
-- Name: connections_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.connections_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.connections_versions_id_seq OWNER TO root;

--
-- Name: connections_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.connections_versions_id_seq OWNED BY public.connections_versions.id;


--
-- Name: company_connections id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_connections ALTER COLUMN id SET DEFAULT nextval('public.company_connections_id_seq'::regclass);


--
-- Name: company_connections_versions id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_connections_versions ALTER COLUMN id SET DEFAULT nextval('public.company_connections_versions_id_seq'::regclass);


--
-- Name: connections id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.connections ALTER COLUMN id SET DEFAULT nextval('public.connections_id_seq'::regclass);


--
-- Name: connections_versions id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.connections_versions ALTER COLUMN id SET DEFAULT nextval('public.connections_versions_id_seq'::regclass);


--
-- Data for Name: company_connections; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.company_connections (id, customer, vendor, status, message, reason, change_status_date, change_status_company, change_status_user) FROM stdin;
1	testCustVendID	testVendCustID	CONNECTED	\N	\N	1614714033118	testCustVendID	82
49	buyerinc	vendorinc	REJECTED	\N	\N	1622449856606	vendorinc	172
3	r5	123123123	CONNECTED	\N	\N	1614756554202	r5	6
6	r10	O44	SENT	I am interested in cooperation with your company.	\N	1614759196300	O44	83
36	Barb1	BAHel	CONNECTED	\N	\N	1622197059550	Barb1	153
5	R44	O44	CONNECTED	\N	\N	1622443578083	O44	83
8	O44	v5	REJECTED	\N	\N	1614762656606	v5	31
9	123123123	v5	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1614762663335	v5	31
10	r1	v23	CONNECTED	\N	\N	1615534802252	v23	49
21	r19	v23	CONNECTED	\N	\N	1617018464026	r19	20
22	r19	v24	CONNECTED	\N	\N	1617082072446	r19	20
23	r1	v11	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1617182063913	r1	2
11	r1	v1	CONNECTED	\N	\N	1622283963273	v1	27
12	vladcustomerautotest	vladautotest	CONNECTED	\N	\N	1616664008981	vladcustomerautotest	94
13	Test111	O44	CONNECTED	\N	\N	1616665683395	O44	83
38	AIM123	v4	CONNECTED	\N	\N	1622201215752	AIM123	149
39	AIM123	DariaTest1	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1622205847015	AIM123	149
20	r2	v5	CONNECTED	\N	\N	1617182539696	v5	31
14	o20	testVendCustID	DISCONNECTED	\N	\N	1616666703885	testVendCustID	78
15	r5	v1	CONNECTED	\N	\N	1616667826565	r5	6
16	Tmc	O44	CONNECTED	\N	\N	1616668540265	O44	83
24	o2	v1	REJECTED	\N	\N	1617185569453	v1	27
18	r4	testVendCustID	CONNECTED	\N	\N	1622212867026	r4	5
25	rautotest	vautotest	CONNECTED	\N	\N	1617194658783	rautotest	107
54	r6	O44	REJECTED	\N	\N	1623074931464	O44	191
27	r6	v21	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1617265286554	r6	7
28	r6	v14	REJECTED	\N	\N	1617265788004	r6	7
29	r6	v13	REJECTED	\N	YYYYYYYYY00000000000))))))))))))))))	1617265840187	v13	39
30	122345	v10	REJECTED	\N	do;fjheporjghopwkef[kq]eflq][ef	1617266069593	v10	36
37	Barb1	v1	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1622464668005	v1	27
26	r4	v5	CONNECTED	\N	\N	1622456734785	v5	31
31	rautotest	vladautotest	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1617620847139	vladautotest	93
40	BAHel	v1	CONNECTED	\N	\N	1622464765313	BAHel	158
19	122345	v1	CONNECTED	\N	\N	1617711835128	v1	27
7	r1	O44	DISCONNECTED	\N	\N	1617873078395	O44	83
32	1029384756	vendorautotest	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1619426317116	vendorautotest	117
33	rAutoTestVika	vendorautotest	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1619426321480	vendorautotest	117
34	vikautotest	vendorautotest	CONNECTED	\N	\N	1619426381122	vendorautotest	117
46	r10	vendorinc	DISCONNECTED	\N	\N	1622278866785	vendorinc	172
4	r5	v5	CONNECTED	\N	\N	1619762140562	v5	31
53	o1	DariaTest1	CONNECTED	\N	\N	1622541862616	DariaTest1	155
35	vladcustomerautotest	vladtest	SENT	I am interested in cooperation with your company.	\N	1622191686766	vladtest	151
43	r18	DariaTest4	CONNECTED	\N	\N	1622275313047	DariaTest4	167
52	DariaTest1	o1	CONNECTED	\N	\N	1622542099645	DariaTest1	155
47	o23	vendorinc	SENT	I am interested in cooperation with your company.	\N	1622279068873	vendorinc	172
48	o1	vendorinc	CONNECTED	\N	\N	1622279818301	o1	52
45	r1	vendorinc	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1622280228087	r1	2
50	buyerinc	buyervendoroff	CONNECTED	\N	\N	1622282348159	buyervendoroff	173
51	buyervendoroff	buyervendoroff	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1622283251318	buyervendoroff	173
44	r6	v5	DISCONNECTED	\N	\N	1622297243751	r6	7
17	r6	v1	DISCONNECTED	\N	\N	1622297245180	r6	7
42	r6	v6	DISCONNECTED	\N	\N	1622297246784	r6	7
2	r6	v2	DISCONNECTED	\N	\N	1622297248335	r6	7
96	Vautotest	vendautotest	REJECTED	\N	\N	1623674218910	vendautotest	145
41	r4	v4	CONNECTED	\N	\N	1622298714924	v4	30
55	r10	v1	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1622304556678	v1	27
56	fg4w45	v1	CONNECTED	\N	\N	1622448354657	fg4w45	247
57	098765	vendorinc	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1622448933943	vendorinc	172
58	buyervendoroff	vendorinc	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1622448937445	vendorinc	172
61	o14	testVendCustID	CONNECTED	\N	\N	1622450753630	o14	65
60	o15	testVendCustID	CONNECTED	\N	\N	1622450778101	o15	66
59	o21	testVendCustID	CONNECTED	\N	\N	1622450804336	o21	72
62	r17	v1	CONNECTED	\N	\N	1622453598426	v1	27
63	O44	v11	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1622456900358	v11	37
65	o12	BAHel	CONNECTED	\N	\N	1622464750300	BAHel	158
66	BAHel	o6	CONNECTED	\N	\N	1622464760476	BAHel	158
67	O44	v6	CONNECTED	\N	\N	1622465306665	O44	83
68	Vautotest	vautotest	SENT	I am interested in cooperation with your company.	\N	1622466519097	vautotest	106
69	BAHel	Bensonshoes	INVITE	Я заинтересован в сотрудничестве с вашей компанией.	\N	1622468138445	BAHel	158
70	r1	BAHel	CONNECTED	\N	\N	1622472519861	BAHel	158
71	r3	o1	CONNECTED	\N	\N	1622529579216	o1	52
79	company8	o1	CONNECTED	\N	\N	1622542034931	o1	52
75	company2	o1	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1623656254369	o1	52
78	o1	company8	CONNECTED	\N	\N	1622542067096	o1	52
76	o1	company4	CONNECTED	\N	\N	1622542068505	o1	52
73	o1	company3	CONNECTED	\N	\N	1622542070902	o1	52
72	o1	company2	CONNECTED	\N	\N	1622542072740	o1	52
82	r1	o3	CONNECTED	\N	\N	1622666928450	r1	2
83	o3	v1	CONNECTED	\N	\N	1622666947484	v1	27
84	r1	v2	CONNECTED	\N	\N	1622668216789	r1	2
80	custautotest	vendautotest	CONNECTED	\N	\N	1623674551298	custautotest	146
74	company3	o1	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1623656440938	o1	52
85	TC11	O44	REJECTED	\N	\N	1623072342113	O44	83
94	r6	v4	CONNECTED	\N	\N	1623662251799	v4	30
64	r2	O44	DISCONNECTED	\N	\N	1623075631086	O44	83
86	106706408	v1	SENT	I am interested in cooperation with your company.	\N	1623225414592	v1	27
93	o1	sdasdasd	SENT	I am interested in cooperation with your company.	\N	1623667830535	o1	52
95	o1	107386525	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1623669334084	o1	52
87	r2	v6	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1623245065479	v6	32
88	o1	Bensonshoes	INVITE	Я заинтересован в сотрудничестве с вашей компанией.	\N	1623325960210	o1	52
89	BAHel	o1	CONNECTED	\N	\N	1623395507085	BAHel	154
90	102566382	o1	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1623409377349	o1	52
91	105781845	o1	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1623409420495	o1	52
92	107315049	o1	REJECTED	\N	\N	1623410063507	o1	52
81	TC1	O44	CONNECTED	\N	\N	1623654117113	TC1	292
77	company4	o1	SENT	Я заинтересован в сотрудничестве с вашей компанией.	\N	1623654912401	o1	52
\.


--
-- Data for Name: company_connections_versions; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.company_connections_versions (id, connection_id, time_stamp, data) FROM stdin;
1	1	1614713985360	{"id":1,"customer":"testCustVendID","vendor":"testVendCustID","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1614713985300,"change_status_company":"testVendCustID","change_status_user":78}
2	1	1614714033276	{"id":1,"customer":"testCustVendID","vendor":"testVendCustID","status":"CONNECTED","message":null,"reason":null,"change_status_date":1614714033118,"change_status_company":"testCustVendID","change_status_user":82}
3	2	1614753833214	{"id":2,"customer":"r6","vendor":"v2","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1614753833207,"change_status_company":"v2","change_status_user":28}
4	2	1614753852558	{"id":2,"customer":"r6","vendor":"v2","status":"CONNECTED","message":null,"reason":null,"change_status_date":1614753852555,"change_status_company":"r6","change_status_user":7}
5	3	1614756530431	{"id":3,"customer":"r5","vendor":"123123123","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1614756530397,"change_status_company":"123123123","change_status_user":80}
6	3	1614756554203	{"id":3,"customer":"r5","vendor":"123123123","status":"CONNECTED","message":null,"reason":null,"change_status_date":1614756554202,"change_status_company":"r5","change_status_user":6}
7	4	1614757997710	{"id":4,"customer":"r5","vendor":"v5","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1614757997687,"change_status_company":"v5","change_status_user":31}
8	4	1614758022343	{"id":4,"customer":"r5","vendor":"v5","status":"CONNECTED","message":null,"reason":null,"change_status_date":1614758022341,"change_status_company":"r5","change_status_user":6}
9	5	1614759194710	{"id":5,"customer":"R44","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1614759194648,"change_status_company":"O44","change_status_user":83}
10	6	1614759196302	{"id":6,"customer":"r10","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1614759196300,"change_status_company":"O44","change_status_user":83}
11	7	1614759199998	{"id":7,"customer":"r1","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1614759199996,"change_status_company":"O44","change_status_user":83}
12	5	1614760789968	{"id":5,"customer":"R44","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1614760789965,"change_status_company":"R44","change_status_user":79}
13	5	1614762258897	{"id":5,"customer":"R44","vendor":"O44","status":"DISCONNECTED","message":null,"reason":"HAHAHA","change_status_date":1614762258896,"change_status_company":"R44","change_status_user":79}
14	5	1614762278396	{"id":5,"customer":"R44","vendor":"O44","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1614762278394,"change_status_company":"O44","change_status_user":83}
15	5	1614762287202	{"id":5,"customer":"R44","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1614762287201,"change_status_company":"R44","change_status_user":79}
16	5	1614762295566	{"id":5,"customer":"R44","vendor":"O44","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1614762295564,"change_status_company":"O44","change_status_user":83}
17	5	1614762301541	{"id":5,"customer":"R44","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1614762301539,"change_status_company":"R44","change_status_user":79}
18	8	1614762653648	{"id":8,"customer":"O44","vendor":"v5","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1614762653615,"change_status_company":"v5","change_status_user":31}
19	8	1614762656607	{"id":8,"customer":"O44","vendor":"v5","status":"REJECTED","message":null,"reason":null,"change_status_date":1614762656606,"change_status_company":"v5","change_status_user":31}
20	9	1614762663338	{"id":9,"customer":"123123123","vendor":"v5","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1614762663335,"change_status_company":"v5","change_status_user":31}
21	10	1615534784493	{"id":10,"customer":"r1","vendor":"v23","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1615534784435,"change_status_company":"r1","change_status_user":2}
22	10	1615534802258	{"id":10,"customer":"r1","vendor":"v23","status":"CONNECTED","message":null,"reason":null,"change_status_date":1615534802252,"change_status_company":"v23","change_status_user":49}
23	11	1615534854671	{"id":11,"customer":"r1","vendor":"v1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1615534854652,"change_status_company":"v1","change_status_user":27}
24	11	1615810945265	{"id":11,"customer":"r1","vendor":"v1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1615810945256,"change_status_company":"r1","change_status_user":2}
25	11	1615811061742	{"id":11,"customer":"r1","vendor":"v1","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1615811061738,"change_status_company":"v1","change_status_user":27}
26	11	1615811150949	{"id":11,"customer":"r1","vendor":"v1","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1615811150945,"change_status_company":"v1","change_status_user":27}
27	11	1615811210975	{"id":11,"customer":"r1","vendor":"v1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1615811210972,"change_status_company":"r1","change_status_user":2}
28	11	1615811230016	{"id":11,"customer":"r1","vendor":"v1","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1615811230014,"change_status_company":"v1","change_status_user":27}
29	12	1616663683877	{"id":12,"customer":"vladcustomerautotest","vendor":"vladautotest","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1616663683771,"change_status_company":"vladautotest","change_status_user":93}
30	12	1616664008989	{"id":12,"customer":"vladcustomerautotest","vendor":"vladautotest","status":"CONNECTED","message":null,"reason":null,"change_status_date":1616664008981,"change_status_company":"vladcustomerautotest","change_status_user":94}
31	13	1616665656682	{"id":13,"customer":"Test111","vendor":"O44","status":"SENT","message":"asdasdasd","reason":null,"change_status_date":1616665656552,"change_status_company":"Test111","change_status_user":97}
32	13	1616665683397	{"id":13,"customer":"Test111","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1616665683395,"change_status_company":"O44","change_status_user":83}
33	14	1616666051953	{"id":14,"customer":"o20","vendor":"testVendCustID","status":"SENT","message":"I am interested in cooperation with your company.I am interested in cooperation with your company.I am interested in cooperation with your company.I am interested in cooperation with your company.I am interested in cooperation with your company.I am interested in cooperation with your company.I am interested in cooperation with your company.I am interested in cooperation with your company.I am interested in cooperation with your company.I am interested in cooperation with your company.I am interested in coo","reason":null,"change_status_date":1616666051646,"change_status_company":"o20","change_status_user":71}
34	14	1616666077324	{"id":14,"customer":"o20","vendor":"testVendCustID","status":"REJECTED","message":null,"reason":"ReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonRe","change_status_date":1616666077320,"change_status_company":"testVendCustID","change_status_user":78}
35	14	1616666402406	{"id":14,"customer":"o20","vendor":"testVendCustID","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1616666402403,"change_status_company":"o20","change_status_user":71}
36	14	1616666421578	{"id":14,"customer":"o20","vendor":"testVendCustID","status":"REJECTED","message":null,"reason":"ReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonReasonRe","change_status_date":1616666421576,"change_status_company":"testVendCustID","change_status_user":78}
37	14	1616666488454	{"id":14,"customer":"o20","vendor":"testVendCustID","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1616666488451,"change_status_company":"o20","change_status_user":71}
38	14	1616666512862	{"id":14,"customer":"o20","vendor":"testVendCustID","status":"CONNECTED","message":null,"reason":null,"change_status_date":1616666512859,"change_status_company":"testVendCustID","change_status_user":78}
39	14	1616666703888	{"id":14,"customer":"o20","vendor":"testVendCustID","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1616666703885,"change_status_company":"testVendCustID","change_status_user":78}
40	15	1616667707112	{"id":15,"customer":"r5","vendor":"v1","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1616667707062,"change_status_company":"v1","change_status_user":27}
41	15	1616667826568	{"id":15,"customer":"r5","vendor":"v1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1616667826565,"change_status_company":"r5","change_status_user":6}
42	16	1616668477126	{"id":16,"customer":"Tmc","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1616668477097,"change_status_company":"Tmc","change_status_user":96}
43	16	1616668540268	{"id":16,"customer":"Tmc","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1616668540265,"change_status_company":"O44","change_status_user":83}
44	17	1616669550907	{"id":17,"customer":"r6","vendor":"v1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1616669550872,"change_status_company":"r6","change_status_user":7}
45	17	1616669579706	{"id":17,"customer":"r6","vendor":"v1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1616669579704,"change_status_company":"v1","change_status_user":27}
46	18	1616676988013	{"id":18,"customer":"r4","vendor":"testVendCustID","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1616676987929,"change_status_company":"testVendCustID","change_status_user":78}
47	4	1617011346226	{"id":4,"customer":"r5","vendor":"v5","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1617011346224,"change_status_company":"v5","change_status_user":31}
48	4	1617012119600	{"id":4,"customer":"r5","vendor":"v5","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1617012119596,"change_status_company":"v5","change_status_user":31}
49	4	1617012138742	{"id":4,"customer":"r5","vendor":"v5","status":"CONNECTED","message":null,"reason":null,"change_status_date":1617012138739,"change_status_company":"r5","change_status_user":6}
50	4	1617012167061	{"id":4,"customer":"r5","vendor":"v5","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1617012167059,"change_status_company":"r5","change_status_user":6}
51	19	1617014145651	{"id":19,"customer":"122345","vendor":"v1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1617014145615,"change_status_company":"122345","change_status_user":100}
52	19	1617014160063	{"id":19,"customer":"122345","vendor":"v1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1617014160061,"change_status_company":"v1","change_status_user":27}
53	20	1617014461628	{"id":20,"customer":"r2","vendor":"v5","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1617014461534,"change_status_company":"r2","change_status_user":3}
54	7	1617014716186	{"id":7,"customer":"r1","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1617014716184,"change_status_company":"r1","change_status_user":2}
55	4	1617015238974	{"id":4,"customer":"r5","vendor":"v5","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1617015238971,"change_status_company":"r5","change_status_user":6}
56	4	1617015306195	{"id":4,"customer":"r5","vendor":"v5","status":"CONNECTED","message":null,"reason":null,"change_status_date":1617015306193,"change_status_company":"v5","change_status_user":31}
57	21	1617018254679	{"id":21,"customer":"r19","vendor":"v23","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1617018254655,"change_status_company":"v23","change_status_user":49}
58	21	1617018464029	{"id":21,"customer":"r19","vendor":"v23","status":"CONNECTED","message":null,"reason":null,"change_status_date":1617018464026,"change_status_company":"r19","change_status_user":20}
59	22	1617081242300	{"id":22,"customer":"r19","vendor":"v24","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1617081242264,"change_status_company":"v24","change_status_user":50}
60	22	1617082072452	{"id":22,"customer":"r19","vendor":"v24","status":"CONNECTED","message":null,"reason":null,"change_status_date":1617082072446,"change_status_company":"r19","change_status_user":20}
61	23	1617182063948	{"id":23,"customer":"r1","vendor":"v11","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1617182063913,"change_status_company":"r1","change_status_user":2}
62	4	1617182409879	{"id":4,"customer":"r5","vendor":"v5","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1617182409877,"change_status_company":"r5","change_status_user":6}
63	4	1617182423210	{"id":4,"customer":"r5","vendor":"v5","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компаниавпролджэдлорлдей.","reason":null,"change_status_date":1617182423208,"change_status_company":"r5","change_status_user":6}
64	4	1617182444544	{"id":4,"customer":"r5","vendor":"v5","status":"REJECTED","message":null,"reason":null,"change_status_date":1617182444541,"change_status_company":"r5","change_status_user":6}
65	4	1617182529945	{"id":4,"customer":"r5","vendor":"v5","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1617182529943,"change_status_company":"r5","change_status_user":6}
66	20	1617182539699	{"id":20,"customer":"r2","vendor":"v5","status":"CONNECTED","message":null,"reason":null,"change_status_date":1617182539696,"change_status_company":"v5","change_status_user":31}
67	4	1617182546331	{"id":4,"customer":"r5","vendor":"v5","status":"CONNECTED","message":null,"reason":null,"change_status_date":1617182546329,"change_status_company":"v5","change_status_user":31}
68	24	1617185503635	{"id":24,"customer":"o2","vendor":"v1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1617185503605,"change_status_company":"v1","change_status_user":27}
69	24	1617185569456	{"id":24,"customer":"o2","vendor":"v1","status":"REJECTED","message":null,"reason":null,"change_status_date":1617185569453,"change_status_company":"v1","change_status_user":27}
70	25	1617194634817	{"id":25,"customer":"rautotest","vendor":"vautotest","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1617194634754,"change_status_company":"vautotest","change_status_user":106}
71	25	1617194658788	{"id":25,"customer":"rautotest","vendor":"vautotest","status":"CONNECTED","message":null,"reason":null,"change_status_date":1617194658783,"change_status_company":"rautotest","change_status_user":107}
72	26	1617263998633	{"id":26,"customer":"r4","vendor":"v5","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1617263998614,"change_status_company":"r4","change_status_user":5}
73	26	1617264219465	{"id":26,"customer":"r4","vendor":"v5","status":"CONNECTED","message":null,"reason":null,"change_status_date":1617264219458,"change_status_company":"v5","change_status_user":31}
74	27	1617265286577	{"id":27,"customer":"r6","vendor":"v21","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1617265286554,"change_status_company":"r6","change_status_user":7}
75	28	1617265783805	{"id":28,"customer":"r6","vendor":"v14","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1617265783785,"change_status_company":"r6","change_status_user":7}
76	28	1617265788005	{"id":28,"customer":"r6","vendor":"v14","status":"REJECTED","message":null,"reason":null,"change_status_date":1617265788004,"change_status_company":"r6","change_status_user":7}
77	29	1617265802839	{"id":29,"customer":"r6","vendor":"v13","status":"SENT","message":"111111111111\\"\\"\\"\\"\\"\\"\\"\\"\\"@@@@@@@@","reason":null,"change_status_date":1617265802818,"change_status_company":"r6","change_status_user":7}
78	29	1617265840189	{"id":29,"customer":"r6","vendor":"v13","status":"REJECTED","message":null,"reason":"YYYYYYYYY00000000000))))))))))))))))","change_status_date":1617265840187,"change_status_company":"v13","change_status_user":39}
79	30	1617266040228	{"id":30,"customer":"122345","vendor":"v10","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.fssefweeef","reason":null,"change_status_date":1617266040220,"change_status_company":"122345","change_status_user":100}
80	30	1617266069594	{"id":30,"customer":"122345","vendor":"v10","status":"REJECTED","message":null,"reason":"do;fjheporjghopwkef[kq]eflq][ef","change_status_date":1617266069593,"change_status_company":"v10","change_status_user":36}
81	5	1617266536511	{"id":5,"customer":"R44","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1617266536509,"change_status_company":"O44","change_status_user":83}
82	5	1617266544201	{"id":5,"customer":"R44","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1617266544200,"change_status_company":"O44","change_status_user":83}
83	19	1617268340768	{"id":19,"customer":"122345","vendor":"v1","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1617268340765,"change_status_company":"v1","change_status_user":27}
84	31	1617620847348	{"id":31,"customer":"rautotest","vendor":"vladautotest","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1617620847139,"change_status_company":"vladautotest","change_status_user":93}
85	4	1617698972741	{"id":4,"customer":"r5","vendor":"v5","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1617698972728,"change_status_company":"r5","change_status_user":6}
86	19	1617711820716	{"id":19,"customer":"122345","vendor":"v1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1617711820707,"change_status_company":"122345","change_status_user":100}
87	19	1617711835131	{"id":19,"customer":"122345","vendor":"v1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1617711835128,"change_status_company":"v1","change_status_user":27}
88	7	1617873078417	{"id":7,"customer":"r1","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1617873078395,"change_status_company":"O44","change_status_user":83}
89	32	1619426317603	{"id":32,"customer":"1029384756","vendor":"vendorautotest","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1619426317116,"change_status_company":"vendorautotest","change_status_user":117}
90	33	1619426321485	{"id":33,"customer":"rAutoTestVika","vendor":"vendorautotest","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1619426321480,"change_status_company":"vendorautotest","change_status_user":117}
91	34	1619426363810	{"id":34,"customer":"vikautotest","vendor":"vendorautotest","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1619426363801,"change_status_company":"vikautotest","change_status_user":116}
92	34	1619426381136	{"id":34,"customer":"vikautotest","vendor":"vendorautotest","status":"CONNECTED","message":null,"reason":null,"change_status_date":1619426381122,"change_status_company":"vendorautotest","change_status_user":117}
93	4	1619762126090	{"id":4,"customer":"r5","vendor":"v5","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1619762126071,"change_status_company":"r5","change_status_user":6}
94	4	1619762140566	{"id":4,"customer":"r5","vendor":"v5","status":"CONNECTED","message":null,"reason":null,"change_status_date":1619762140562,"change_status_company":"v5","change_status_user":31}
95	5	1620044462971	{"id":5,"customer":"R44","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1620044462958,"change_status_company":"R44","change_status_user":79}
96	35	1622191686870	{"id":35,"customer":"vladcustomerautotest","vendor":"vladtest","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622191686766,"change_status_company":"vladtest","change_status_user":151}
97	36	1622197027446	{"id":36,"customer":"Barb1","vendor":"BAHel","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622197027355,"change_status_company":"BAHel","change_status_user":154}
98	36	1622197059562	{"id":36,"customer":"Barb1","vendor":"BAHel","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622197059550,"change_status_company":"Barb1","change_status_user":153}
99	11	1622201087458	{"id":11,"customer":"r1","vendor":"v1","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622201087451,"change_status_company":"r1","change_status_user":2}
100	37	1622201150702	{"id":37,"customer":"Barb1","vendor":"v1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622201150675,"change_status_company":"v1","change_status_user":27}
101	38	1622201206235	{"id":38,"customer":"AIM123","vendor":"v4","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622201206210,"change_status_company":"v4","change_status_user":30}
102	38	1622201215754	{"id":38,"customer":"AIM123","vendor":"v4","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622201215752,"change_status_company":"AIM123","change_status_user":149}
103	39	1622205847041	{"id":39,"customer":"AIM123","vendor":"DariaTest1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622205847015,"change_status_company":"AIM123","change_status_user":149}
104	37	1622209935605	{"id":37,"customer":"Barb1","vendor":"v1","status":"REJECTED","message":null,"reason":null,"change_status_date":1622209935596,"change_status_company":"v1","change_status_user":27}
105	40	1622210015425	{"id":40,"customer":"BAHel","vendor":"v1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622210015408,"change_status_company":"v1","change_status_user":27}
106	41	1622212846278	{"id":41,"customer":"r4","vendor":"v4","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622212846224,"change_status_company":"v4","change_status_user":30}
107	18	1622212867029	{"id":18,"customer":"r4","vendor":"testVendCustID","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622212867026,"change_status_company":"r4","change_status_user":5}
108	41	1622212868828	{"id":41,"customer":"r4","vendor":"v4","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622212868808,"change_status_company":"r4","change_status_user":5}
109	42	1622274888338	{"id":42,"customer":"r6","vendor":"v6","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622274888265,"change_status_company":"r6","change_status_user":7}
110	42	1622274910614	{"id":42,"customer":"r6","vendor":"v6","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622274910606,"change_status_company":"v6","change_status_user":32}
111	42	1622274962438	{"id":42,"customer":"r6","vendor":"v6","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622274962433,"change_status_company":"v6","change_status_user":32}
112	42	1622274990150	{"id":42,"customer":"r6","vendor":"v6","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622274990147,"change_status_company":"r6","change_status_user":7}
113	42	1622275017958	{"id":42,"customer":"r6","vendor":"v6","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622275017955,"change_status_company":"v6","change_status_user":32}
114	42	1622275136736	{"id":42,"customer":"r6","vendor":"v6","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622275136734,"change_status_company":"r6","change_status_user":7}
115	43	1622275278581	{"id":43,"customer":"r18","vendor":"DariaTest4","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622275278567,"change_status_company":"r18","change_status_user":19}
116	43	1622275313050	{"id":43,"customer":"r18","vendor":"DariaTest4","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622275313047,"change_status_company":"DariaTest4","change_status_user":167}
117	42	1622276948344	{"id":42,"customer":"r6","vendor":"v6","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622276948340,"change_status_company":"v6","change_status_user":32}
118	42	1622276970453	{"id":42,"customer":"r6","vendor":"v6","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622276970451,"change_status_company":"r6","change_status_user":7}
119	42	1622276975414	{"id":42,"customer":"r6","vendor":"v6","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622276975412,"change_status_company":"r6","change_status_user":7}
120	42	1622276986408	{"id":42,"customer":"r6","vendor":"v6","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622276986406,"change_status_company":"v6","change_status_user":32}
121	42	1622277800949	{"id":42,"customer":"r6","vendor":"v6","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622277800945,"change_status_company":"r6","change_status_user":7}
122	44	1622277889543	{"id":44,"customer":"r6","vendor":"v5","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622277889532,"change_status_company":"v5","change_status_user":31}
123	44	1622277895995	{"id":44,"customer":"r6","vendor":"v5","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622277895992,"change_status_company":"r6","change_status_user":7}
124	45	1622278691459	{"id":45,"customer":"r1","vendor":"vendorinc","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622278691439,"change_status_company":"vendorinc","change_status_user":172}
125	45	1622278718294	{"id":45,"customer":"r1","vendor":"vendorinc","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622278718289,"change_status_company":"r1","change_status_user":2}
126	45	1622278731011	{"id":45,"customer":"r1","vendor":"vendorinc","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622278731008,"change_status_company":"r1","change_status_user":2}
127	45	1622278743386	{"id":45,"customer":"r1","vendor":"vendorinc","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622278743384,"change_status_company":"r1","change_status_user":2}
128	45	1622278773742	{"id":45,"customer":"r1","vendor":"vendorinc","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622278773741,"change_status_company":"vendorinc","change_status_user":172}
129	45	1622278782300	{"id":45,"customer":"r1","vendor":"vendorinc","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622278782297,"change_status_company":"vendorinc","change_status_user":172}
130	46	1622278803649	{"id":46,"customer":"r10","vendor":"vendorinc","status":"SENT","message":"I am interested in cooperation withкпыукпывупывуы your company.","reason":null,"change_status_date":1622278803642,"change_status_company":"vendorinc","change_status_user":172}
131	46	1622278825539	{"id":46,"customer":"r10","vendor":"vendorinc","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622278825537,"change_status_company":"r10","change_status_user":11}
132	46	1622278866787	{"id":46,"customer":"r10","vendor":"vendorinc","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622278866785,"change_status_company":"vendorinc","change_status_user":172}
133	47	1622278885702	{"id":47,"customer":"o23","vendor":"vendorinc","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622278885690,"change_status_company":"vendorinc","change_status_user":172}
134	44	1622279011592	{"id":44,"customer":"r6","vendor":"v5","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622279011590,"change_status_company":"v5","change_status_user":31}
135	47	1622279021690	{"id":47,"customer":"o23","vendor":"vendorinc","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622279021688,"change_status_company":"o23","change_status_user":74}
136	47	1622279024898	{"id":47,"customer":"o23","vendor":"vendorinc","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622279024896,"change_status_company":"o23","change_status_user":74}
137	47	1622279035293	{"id":47,"customer":"o23","vendor":"vendorinc","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622279035289,"change_status_company":"o23","change_status_user":74}
138	47	1622279065702	{"id":47,"customer":"o23","vendor":"vendorinc","status":"REJECTED","message":null,"reason":null,"change_status_date":1622279065699,"change_status_company":"vendorinc","change_status_user":172}
139	47	1622279068875	{"id":47,"customer":"o23","vendor":"vendorinc","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622279068873,"change_status_company":"vendorinc","change_status_user":172}
140	48	1622279791912	{"id":48,"customer":"o1","vendor":"vendorinc","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622279791882,"change_status_company":"vendorinc","change_status_user":172}
141	48	1622279818304	{"id":48,"customer":"o1","vendor":"vendorinc","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622279818301,"change_status_company":"o1","change_status_user":52}
142	45	1622280228091	{"id":45,"customer":"r1","vendor":"vendorinc","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622280228087,"change_status_company":"r1","change_status_user":2}
143	49	1622282277823	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией. Hi","reason":null,"change_status_date":1622282277784,"change_status_company":"vendorinc","change_status_user":172}
144	49	1622282308490	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622282308487,"change_status_company":"buyerinc","change_status_user":171}
145	50	1622282333120	{"id":50,"customer":"buyerinc","vendor":"buyervendoroff","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622282333111,"change_status_company":"buyerinc","change_status_user":171}
146	50	1622282348162	{"id":50,"customer":"buyerinc","vendor":"buyervendoroff","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622282348159,"change_status_company":"buyervendoroff","change_status_user":173}
147	51	1622283251365	{"id":51,"customer":"buyervendoroff","vendor":"buyervendoroff","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622283251318,"change_status_company":"buyervendoroff","change_status_user":173}
148	11	1622283963275	{"id":11,"customer":"r1","vendor":"v1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622283963273,"change_status_company":"v1","change_status_user":27}
149	44	1622284736840	{"id":44,"customer":"r6","vendor":"v5","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622284736835,"change_status_company":"v5","change_status_user":31}
150	44	1622284744036	{"id":44,"customer":"r6","vendor":"v5","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622284744033,"change_status_company":"r6","change_status_user":7}
151	52	1622286529342	{"id":52,"customer":"DariaTest1","vendor":"o1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622286529327,"change_status_company":"o1","change_status_user":52}
152	53	1622286606820	{"id":53,"customer":"o1","vendor":"DariaTest1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622286606814,"change_status_company":"o1","change_status_user":52}
153	53	1622286819076	{"id":53,"customer":"o1","vendor":"DariaTest1","status":"REJECTED","message":null,"reason":null,"change_status_date":1622286819074,"change_status_company":"o1","change_status_user":52}
154	53	1622286835214	{"id":53,"customer":"o1","vendor":"DariaTest1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622286835211,"change_status_company":"o1","change_status_user":52}
155	5	1622288586977	{"id":5,"customer":"R44","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622288586974,"change_status_company":"R44","change_status_user":79}
156	5	1622288625595	{"id":5,"customer":"R44","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622288625593,"change_status_company":"O44","change_status_user":83}
157	5	1622288712284	{"id":5,"customer":"R44","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622288712282,"change_status_company":"R44","change_status_user":79}
158	5	1622288867290	{"id":5,"customer":"R44","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622288867288,"change_status_company":"O44","change_status_user":83}
159	5	1622288888068	{"id":5,"customer":"R44","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622288888065,"change_status_company":"R44","change_status_user":79}
160	5	1622288897516	{"id":5,"customer":"R44","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622288897513,"change_status_company":"O44","change_status_user":83}
161	5	1622288911340	{"id":5,"customer":"R44","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622288911338,"change_status_company":"O44","change_status_user":83}
162	5	1622288916681	{"id":5,"customer":"R44","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622288916673,"change_status_company":"R44","change_status_user":79}
163	5	1622289146753	{"id":5,"customer":"R44","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1622289146749,"change_status_company":"O44","change_status_user":83}
164	5	1622289187668	{"id":5,"customer":"R44","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622289187665,"change_status_company":"R44","change_status_user":79}
165	5	1622289208899	{"id":5,"customer":"R44","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622289208897,"change_status_company":"O44","change_status_user":83}
166	5	1622289220699	{"id":5,"customer":"R44","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622289220698,"change_status_company":"O44","change_status_user":83}
167	54	1622293054494	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622293054461,"change_status_company":"O44","change_status_user":83}
168	54	1622293061602	{"id":54,"customer":"r6","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622293061599,"change_status_company":"r6","change_status_user":7}
169	54	1622293093569	{"id":54,"customer":"r6","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622293093567,"change_status_company":"O44","change_status_user":83}
170	54	1622293449529	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622293449527,"change_status_company":"O44","change_status_user":83}
171	54	1622293452703	{"id":54,"customer":"r6","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622293452701,"change_status_company":"r6","change_status_user":7}
172	54	1622293503698	{"id":54,"customer":"r6","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622293503697,"change_status_company":"O44","change_status_user":83}
173	54	1622293508258	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622293508256,"change_status_company":"r6","change_status_user":7}
174	54	1622293530122	{"id":54,"customer":"r6","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1622293530121,"change_status_company":"O44","change_status_user":83}
175	54	1622293532544	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622293532542,"change_status_company":"O44","change_status_user":83}
176	54	1622293535809	{"id":54,"customer":"r6","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1622293535808,"change_status_company":"r6","change_status_user":7}
177	54	1622293552030	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622293552027,"change_status_company":"O44","change_status_user":83}
178	54	1622293567473	{"id":54,"customer":"r6","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622293567470,"change_status_company":"r6","change_status_user":7}
179	54	1622293604421	{"id":54,"customer":"r6","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622293604418,"change_status_company":"r6","change_status_user":7}
180	54	1622293820754	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622293820752,"change_status_company":"r6","change_status_user":7}
181	44	1622297243757	{"id":44,"customer":"r6","vendor":"v5","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622297243751,"change_status_company":"r6","change_status_user":7}
182	17	1622297245193	{"id":17,"customer":"r6","vendor":"v1","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622297245180,"change_status_company":"r6","change_status_user":7}
183	42	1622297246786	{"id":42,"customer":"r6","vendor":"v6","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622297246784,"change_status_company":"r6","change_status_user":7}
184	2	1622297248338	{"id":2,"customer":"r6","vendor":"v2","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622297248335,"change_status_company":"r6","change_status_user":7}
185	54	1622298260838	{"id":54,"customer":"r6","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622298260836,"change_status_company":"O44","change_status_user":83}
186	54	1622298278988	{"id":54,"customer":"r6","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622298278984,"change_status_company":"r6","change_status_user":7}
187	54	1622298313067	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622298313064,"change_status_company":"O44","change_status_user":83}
188	54	1622298321444	{"id":54,"customer":"r6","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1622298321442,"change_status_company":"r6","change_status_user":7}
189	41	1622298677522	{"id":41,"customer":"r4","vendor":"v4","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622298677516,"change_status_company":"r4","change_status_user":5}
190	41	1622298688427	{"id":41,"customer":"r4","vendor":"v4","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622298688425,"change_status_company":"r4","change_status_user":5}
191	41	1622298714927	{"id":41,"customer":"r4","vendor":"v4","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622298714924,"change_status_company":"v4","change_status_user":30}
192	55	1622304556704	{"id":55,"customer":"r10","vendor":"v1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622304556678,"change_status_company":"v1","change_status_user":27}
193	5	1622443571777	{"id":5,"customer":"R44","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622443571766,"change_status_company":"R44","change_status_user":79}
194	5	1622443578086	{"id":5,"customer":"R44","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622443578083,"change_status_company":"O44","change_status_user":83}
195	56	1622448345341	{"id":56,"customer":"fg4w45","vendor":"v1","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622448345287,"change_status_company":"v1","change_status_user":27}
196	56	1622448354665	{"id":56,"customer":"fg4w45","vendor":"v1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622448354657,"change_status_company":"fg4w45","change_status_user":247}
197	57	1622448933957	{"id":57,"customer":"098765","vendor":"vendorinc","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622448933943,"change_status_company":"vendorinc","change_status_user":172}
198	58	1622448937457	{"id":58,"customer":"buyervendoroff","vendor":"vendorinc","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622448937445,"change_status_company":"vendorinc","change_status_user":172}
199	49	1622448948684	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"DISCONNECTED","message":null,"reason":"KGDSH","change_status_date":1622448948682,"change_status_company":"vendorinc","change_status_user":172}
200	49	1622448996601	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622448996599,"change_status_company":"buyerinc","change_status_user":171}
201	49	1622449082823	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622449082807,"change_status_company":"vendorinc","change_status_user":172}
202	49	1622449118015	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622449118013,"change_status_company":"buyerinc","change_status_user":171}
203	49	1622449121802	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622449121799,"change_status_company":"buyerinc","change_status_user":171}
204	49	1622449134527	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622449134525,"change_status_company":"vendorinc","change_status_user":172}
205	49	1622449137879	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622449137877,"change_status_company":"vendorinc","change_status_user":172}
236	54	1622459662711	{"id":54,"customer":"r6","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1622459662708,"change_status_company":"r6","change_status_user":7}
206	49	1622449143285	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622449143283,"change_status_company":"vendorinc","change_status_user":172}
207	49	1622449157581	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622449157578,"change_status_company":"buyerinc","change_status_user":171}
208	49	1622449595514	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"DISCONNECTED","message":null,"reason":"hha","change_status_date":1622449595511,"change_status_company":"buyerinc","change_status_user":171}
209	49	1622449676279	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией. aaaa","reason":null,"change_status_date":1622449676277,"change_status_company":"vendorinc","change_status_user":172}
210	49	1622449718051	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"REJECTED","message":null,"reason":null,"change_status_date":1622449718049,"change_status_company":"buyerinc","change_status_user":171}
211	49	1622449726224	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622449726221,"change_status_company":"buyerinc","change_status_user":171}
212	49	1622449744243	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"REJECTED","message":null,"reason":null,"change_status_date":1622449744241,"change_status_company":"vendorinc","change_status_user":172}
213	49	1622449831170	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622449831168,"change_status_company":"vendorinc","change_status_user":172}
214	49	1622449842974	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"REJECTED","message":null,"reason":null,"change_status_date":1622449842973,"change_status_company":"buyerinc","change_status_user":171}
215	49	1622449847004	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622449847002,"change_status_company":"buyerinc","change_status_user":171}
216	49	1622449856607	{"id":49,"customer":"buyerinc","vendor":"vendorinc","status":"REJECTED","message":null,"reason":null,"change_status_date":1622449856606,"change_status_company":"vendorinc","change_status_user":172}
217	59	1622450621513	{"id":59,"customer":"o21","vendor":"testVendCustID","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622450621476,"change_status_company":"testVendCustID","change_status_user":78}
218	60	1622450698570	{"id":60,"customer":"o15","vendor":"testVendCustID","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622450698542,"change_status_company":"testVendCustID","change_status_user":78}
219	61	1622450700510	{"id":61,"customer":"o14","vendor":"testVendCustID","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622450700506,"change_status_company":"testVendCustID","change_status_user":78}
220	61	1622450753644	{"id":61,"customer":"o14","vendor":"testVendCustID","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622450753630,"change_status_company":"o14","change_status_user":65}
221	60	1622450778104	{"id":60,"customer":"o15","vendor":"testVendCustID","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622450778101,"change_status_company":"o15","change_status_user":66}
222	59	1622450804339	{"id":59,"customer":"o21","vendor":"testVendCustID","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622450804336,"change_status_company":"o21","change_status_user":72}
223	62	1622453579448	{"id":62,"customer":"r17","vendor":"v1","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622453579422,"change_status_company":"r17","change_status_user":18}
224	62	1622453598429	{"id":62,"customer":"r17","vendor":"v1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622453598426,"change_status_company":"v1","change_status_user":27}
225	26	1622456714472	{"id":26,"customer":"r4","vendor":"v5","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622456714457,"change_status_company":"r4","change_status_user":5}
226	26	1622456716950	{"id":26,"customer":"r4","vendor":"v5","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622456716946,"change_status_company":"r4","change_status_user":5}
227	26	1622456734787	{"id":26,"customer":"r4","vendor":"v5","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622456734785,"change_status_company":"v5","change_status_user":31}
228	63	1622456900390	{"id":63,"customer":"O44","vendor":"v11","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622456900358,"change_status_company":"v11","change_status_user":37}
229	64	1622456953173	{"id":64,"customer":"r2","vendor":"O44","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622456953162,"change_status_company":"r2","change_status_user":3}
230	54	1622459594229	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622459594226,"change_status_company":"r6","change_status_user":7}
231	54	1622459617300	{"id":54,"customer":"r6","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1622459617298,"change_status_company":"r6","change_status_user":7}
232	54	1622459634153	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622459634148,"change_status_company":"O44","change_status_user":83}
233	54	1622459638174	{"id":54,"customer":"r6","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622459638172,"change_status_company":"r6","change_status_user":7}
234	54	1622459657830	{"id":54,"customer":"r6","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1622459657829,"change_status_company":"O44","change_status_user":83}
235	54	1622459660601	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622459660599,"change_status_company":"O44","change_status_user":83}
237	54	1622461114427	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622461114424,"change_status_company":"O44","change_status_user":83}
238	54	1622461118203	{"id":54,"customer":"r6","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622461118201,"change_status_company":"r6","change_status_user":7}
239	37	1622464668011	{"id":37,"customer":"Barb1","vendor":"v1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622464668005,"change_status_company":"v1","change_status_user":27}
240	65	1622464692646	{"id":65,"customer":"o12","vendor":"BAHel","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622464692634,"change_status_company":"o12","change_status_user":63}
241	66	1622464712674	{"id":66,"customer":"BAHel","vendor":"o6","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622464712646,"change_status_company":"o6","change_status_user":57}
242	65	1622464750303	{"id":65,"customer":"o12","vendor":"BAHel","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622464750300,"change_status_company":"BAHel","change_status_user":158}
243	66	1622464760480	{"id":66,"customer":"BAHel","vendor":"o6","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622464760476,"change_status_company":"BAHel","change_status_user":158}
244	40	1622464765316	{"id":40,"customer":"BAHel","vendor":"v1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622464765313,"change_status_company":"BAHel","change_status_user":158}
245	67	1622465273385	{"id":67,"customer":"O44","vendor":"v6","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622465273336,"change_status_company":"v6","change_status_user":32}
246	67	1622465306667	{"id":67,"customer":"O44","vendor":"v6","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622465306665,"change_status_company":"O44","change_status_user":83}
247	68	1622466519169	{"id":68,"customer":"Vautotest","vendor":"vautotest","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622466519097,"change_status_company":"vautotest","change_status_user":106}
248	69	1622468138546	{"id":69,"customer":"BAHel","vendor":"Bensonshoes","status":"INVITE","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622468138445,"change_status_company":"BAHel","change_status_user":158}
249	70	1622472434177	{"id":70,"customer":"r1","vendor":"BAHel","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622472434149,"change_status_company":"r1","change_status_user":2}
250	70	1622472519866	{"id":70,"customer":"r1","vendor":"BAHel","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622472519861,"change_status_company":"BAHel","change_status_user":158}
251	71	1622529564676	{"id":71,"customer":"r3","vendor":"o1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622529564590,"change_status_company":"r3","change_status_user":4}
252	71	1622529579222	{"id":71,"customer":"r3","vendor":"o1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622529579216,"change_status_company":"o1","change_status_user":52}
253	53	1622541862626	{"id":53,"customer":"o1","vendor":"DariaTest1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622541862616,"change_status_company":"DariaTest1","change_status_user":155}
254	72	1622541908368	{"id":72,"customer":"o1","vendor":"company2","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622541908297,"change_status_company":"company2","change_status_user":268}
255	73	1622541933464	{"id":73,"customer":"o1","vendor":"company3","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622541933454,"change_status_company":"company3","change_status_user":269}
256	74	1622541941245	{"id":74,"customer":"company3","vendor":"o1","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622541941220,"change_status_company":"company3","change_status_user":269}
257	75	1622541956282	{"id":75,"customer":"company2","vendor":"o1","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622541956276,"change_status_company":"company2","change_status_user":268}
258	76	1622541981644	{"id":76,"customer":"o1","vendor":"company4","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622541981637,"change_status_company":"company4","change_status_user":270}
259	77	1622541984662	{"id":77,"customer":"company4","vendor":"o1","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622541984648,"change_status_company":"company4","change_status_user":270}
260	78	1622542004960	{"id":78,"customer":"o1","vendor":"company8","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622542004955,"change_status_company":"company8","change_status_user":273}
261	79	1622542007934	{"id":79,"customer":"company8","vendor":"o1","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622542007929,"change_status_company":"company8","change_status_user":273}
262	79	1622542034934	{"id":79,"customer":"company8","vendor":"o1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622542034931,"change_status_company":"o1","change_status_user":52}
263	77	1622542036940	{"id":77,"customer":"company4","vendor":"o1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622542036935,"change_status_company":"o1","change_status_user":52}
264	75	1622542038447	{"id":75,"customer":"company2","vendor":"o1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622542038443,"change_status_company":"o1","change_status_user":52}
265	74	1622542040688	{"id":74,"customer":"company3","vendor":"o1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622542040686,"change_status_company":"o1","change_status_user":52}
266	78	1622542067097	{"id":78,"customer":"o1","vendor":"company8","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622542067096,"change_status_company":"o1","change_status_user":52}
267	76	1622542068509	{"id":76,"customer":"o1","vendor":"company4","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622542068505,"change_status_company":"o1","change_status_user":52}
268	73	1622542070903	{"id":73,"customer":"o1","vendor":"company3","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622542070902,"change_status_company":"o1","change_status_user":52}
269	72	1622542072743	{"id":72,"customer":"o1","vendor":"company2","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622542072740,"change_status_company":"o1","change_status_user":52}
270	52	1622542099646	{"id":52,"customer":"DariaTest1","vendor":"o1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622542099645,"change_status_company":"DariaTest1","change_status_user":155}
271	80	1622627586136	{"id":80,"customer":"custautotest","vendor":"vendautotest","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622627585966,"change_status_company":"custautotest","change_status_user":146}
272	80	1622627620377	{"id":80,"customer":"custautotest","vendor":"vendautotest","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622627620366,"change_status_company":"vendautotest","change_status_user":145}
273	81	1622628342214	{"id":81,"customer":"TC1","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1622628342177,"change_status_company":"TC1","change_status_user":292}
274	82	1622666879186	{"id":82,"customer":"r1","vendor":"o3","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622666879125,"change_status_company":"o3","change_status_user":54}
275	83	1622666911202	{"id":83,"customer":"o3","vendor":"v1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622666911182,"change_status_company":"o3","change_status_user":54}
276	82	1622666928465	{"id":82,"customer":"r1","vendor":"o3","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622666928450,"change_status_company":"r1","change_status_user":2}
277	83	1622666947491	{"id":83,"customer":"o3","vendor":"v1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622666947484,"change_status_company":"v1","change_status_user":27}
278	84	1622668195601	{"id":84,"customer":"r1","vendor":"v2","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1622668195586,"change_status_company":"v2","change_status_user":28}
279	84	1622668216791	{"id":84,"customer":"r1","vendor":"v2","status":"CONNECTED","message":null,"reason":null,"change_status_date":1622668216789,"change_status_company":"r1","change_status_user":2}
280	85	1623071758857	{"id":85,"customer":"TC11","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1623071758719,"change_status_company":"TC11","change_status_user":325}
281	85	1623071763154	{"id":85,"customer":"TC11","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1623071763150,"change_status_company":"TC11","change_status_user":325}
282	85	1623072205937	{"id":85,"customer":"TC11","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1623072205934,"change_status_company":"TC11","change_status_user":325}
283	85	1623072334661	{"id":85,"customer":"TC11","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1623072334657,"change_status_company":"O44","change_status_user":191}
284	85	1623072342128	{"id":85,"customer":"TC11","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1623072342113,"change_status_company":"O44","change_status_user":83}
285	54	1623072476007	{"id":54,"customer":"r6","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1623072476000,"change_status_company":"r6","change_status_user":7}
286	54	1623072485430	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1623072485424,"change_status_company":"r6","change_status_user":7}
287	54	1623072498197	{"id":54,"customer":"r6","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1623072498192,"change_status_company":"O44","change_status_user":191}
288	54	1623072505176	{"id":54,"customer":"r6","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1623072505170,"change_status_company":"O44","change_status_user":191}
289	54	1623072529710	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1623072529705,"change_status_company":"r6","change_status_user":7}
290	54	1623072536442	{"id":54,"customer":"r6","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1623072536439,"change_status_company":"O44","change_status_user":191}
291	54	1623072539258	{"id":54,"customer":"r6","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1623072539255,"change_status_company":"O44","change_status_user":83}
292	54	1623072805486	{"id":54,"customer":"r6","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1623072805483,"change_status_company":"r6","change_status_user":7}
293	54	1623072815025	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1623072815022,"change_status_company":"r6","change_status_user":7}
294	54	1623072826423	{"id":54,"customer":"r6","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1623072826421,"change_status_company":"O44","change_status_user":83}
295	54	1623072829624	{"id":54,"customer":"r6","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1623072829621,"change_status_company":"O44","change_status_user":83}
296	54	1623072895913	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1623072895911,"change_status_company":"r6","change_status_user":7}
297	54	1623074005609	{"id":54,"customer":"r6","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1623074005606,"change_status_company":"O44","change_status_user":191}
298	54	1623074024463	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1623074024460,"change_status_company":"r6","change_status_user":7}
299	54	1623074043364	{"id":54,"customer":"r6","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1623074043361,"change_status_company":"O44","change_status_user":191}
300	54	1623074048199	{"id":54,"customer":"r6","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1623074048196,"change_status_company":"O44","change_status_user":83}
301	54	1623074341554	{"id":54,"customer":"r6","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1623074341552,"change_status_company":"O44","change_status_user":83}
302	54	1623074349841	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1623074349838,"change_status_company":"r6","change_status_user":7}
303	54	1623074524505	{"id":54,"customer":"r6","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1623074524501,"change_status_company":"O44","change_status_user":191}
304	54	1623074656602	{"id":54,"customer":"r6","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1623074656597,"change_status_company":"O44","change_status_user":83}
305	54	1623074889388	{"id":54,"customer":"r6","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1623074889386,"change_status_company":"O44","change_status_user":83}
306	54	1623074893652	{"id":54,"customer":"r6","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1623074893650,"change_status_company":"r6","change_status_user":7}
307	54	1623074931467	{"id":54,"customer":"r6","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1623074931464,"change_status_company":"O44","change_status_user":191}
308	64	1623075567632	{"id":64,"customer":"r2","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1623075567628,"change_status_company":"O44","change_status_user":83}
309	64	1623075571717	{"id":64,"customer":"r2","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1623075571715,"change_status_company":"O44","change_status_user":83}
310	64	1623075605803	{"id":64,"customer":"r2","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1623075605800,"change_status_company":"r2","change_status_user":3}
311	64	1623075609170	{"id":64,"customer":"r2","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1623075609167,"change_status_company":"O44","change_status_user":83}
312	64	1623075610577	{"id":64,"customer":"r2","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1623075610575,"change_status_company":"O44","change_status_user":83}
313	64	1623075619795	{"id":64,"customer":"r2","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1623075619791,"change_status_company":"r2","change_status_user":3}
314	64	1623075624901	{"id":64,"customer":"r2","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1623075624898,"change_status_company":"O44","change_status_user":83}
315	64	1623075631087	{"id":64,"customer":"r2","vendor":"O44","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1623075631086,"change_status_company":"O44","change_status_user":83}
316	86	1623225414699	{"id":86,"customer":"106706408","vendor":"v1","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1623225414592,"change_status_company":"v1","change_status_user":27}
317	87	1623243043966	{"id":87,"customer":"r2","vendor":"v6","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623243043936,"change_status_company":"v6","change_status_user":32}
318	87	1623244123187	{"id":87,"customer":"r2","vendor":"v6","status":"REJECTED","message":null,"reason":null,"change_status_date":1623244123182,"change_status_company":"r2","change_status_user":3}
319	87	1623244165835	{"id":87,"customer":"r2","vendor":"v6","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623244165827,"change_status_company":"r2","change_status_user":3}
320	87	1623244204535	{"id":87,"customer":"r2","vendor":"v6","status":"REJECTED","message":null,"reason":null,"change_status_date":1623244204534,"change_status_company":"r2","change_status_user":3}
321	87	1623244211815	{"id":87,"customer":"r2","vendor":"v6","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623244211814,"change_status_company":"r2","change_status_user":3}
322	87	1623244254272	{"id":87,"customer":"r2","vendor":"v6","status":"REJECTED","message":null,"reason":null,"change_status_date":1623244254269,"change_status_company":"r2","change_status_user":3}
323	87	1623244268509	{"id":87,"customer":"r2","vendor":"v6","status":"REJECTED","message":null,"reason":null,"change_status_date":1623244268507,"change_status_company":"r2","change_status_user":3}
324	87	1623244418543	{"id":87,"customer":"r2","vendor":"v6","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623244418541,"change_status_company":"v6","change_status_user":32}
325	87	1623244439788	{"id":87,"customer":"r2","vendor":"v6","status":"REJECTED","message":null,"reason":null,"change_status_date":1623244439786,"change_status_company":"r2","change_status_user":3}
326	87	1623244508826	{"id":87,"customer":"r2","vendor":"v6","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623244508824,"change_status_company":"v6","change_status_user":32}
327	87	1623244556731	{"id":87,"customer":"r2","vendor":"v6","status":"REJECTED","message":null,"reason":null,"change_status_date":1623244556730,"change_status_company":"r2","change_status_user":3}
328	87	1623244569895	{"id":87,"customer":"r2","vendor":"v6","status":"CONNECTED","message":null,"reason":null,"change_status_date":1623244569892,"change_status_company":"r2","change_status_user":3}
329	87	1623245051235	{"id":87,"customer":"r2","vendor":"v6","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1623245051231,"change_status_company":"r2","change_status_user":3}
330	87	1623245065481	{"id":87,"customer":"r2","vendor":"v6","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623245065479,"change_status_company":"v6","change_status_user":32}
331	88	1623325960383	{"id":88,"customer":"o1","vendor":"Bensonshoes","status":"INVITE","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623325960210,"change_status_company":"o1","change_status_user":52}
332	89	1623395487525	{"id":89,"customer":"BAHel","vendor":"o1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623395487472,"change_status_company":"o1","change_status_user":52}
333	89	1623395507093	{"id":89,"customer":"BAHel","vendor":"o1","status":"CONNECTED","message":null,"reason":null,"change_status_date":1623395507085,"change_status_company":"BAHel","change_status_user":154}
334	90	1623409377468	{"id":90,"customer":"102566382","vendor":"o1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623409377349,"change_status_company":"o1","change_status_user":52}
335	91	1623409420505	{"id":91,"customer":"105781845","vendor":"o1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623409420495,"change_status_company":"o1","change_status_user":52}
336	92	1623409518081	{"id":92,"customer":"107315049","vendor":"o1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623409518073,"change_status_company":"o1","change_status_user":52}
337	92	1623410063518	{"id":92,"customer":"107315049","vendor":"o1","status":"REJECTED","message":null,"reason":null,"change_status_date":1623410063507,"change_status_company":"o1","change_status_user":52}
338	93	1623410267873	{"id":93,"customer":"o1","vendor":"sdasdasd","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623410267834,"change_status_company":"o1","change_status_user":52}
339	81	1623653671855	{"id":81,"customer":"TC1","vendor":"O44","status":"REJECTED","message":null,"reason":null,"change_status_date":1623653671850,"change_status_company":"TC1","change_status_user":292}
340	81	1623653693696	{"id":81,"customer":"TC1","vendor":"O44","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1623653693693,"change_status_company":"O44","change_status_user":83}
341	81	1623654117119	{"id":81,"customer":"TC1","vendor":"O44","status":"CONNECTED","message":null,"reason":null,"change_status_date":1623654117113,"change_status_company":"TC1","change_status_user":292}
342	77	1623654891182	{"id":77,"customer":"company4","vendor":"o1","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1623654891178,"change_status_company":"o1","change_status_user":52}
343	77	1623654912406	{"id":77,"customer":"company4","vendor":"o1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623654912401,"change_status_company":"o1","change_status_user":52}
344	75	1623656139460	{"id":75,"customer":"company2","vendor":"o1","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1623656139457,"change_status_company":"o1","change_status_user":52}
345	75	1623656254373	{"id":75,"customer":"company2","vendor":"o1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623656254369,"change_status_company":"o1","change_status_user":52}
346	74	1623656403169	{"id":74,"customer":"company3","vendor":"o1","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1623656403167,"change_status_company":"o1","change_status_user":52}
347	74	1623656440940	{"id":74,"customer":"company3","vendor":"o1","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623656440938,"change_status_company":"o1","change_status_user":52}
348	94	1623662240697	{"id":94,"customer":"r6","vendor":"v4","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623662240476,"change_status_company":"r6","change_status_user":7}
349	94	1623662251803	{"id":94,"customer":"r6","vendor":"v4","status":"CONNECTED","message":null,"reason":null,"change_status_date":1623662251799,"change_status_company":"v4","change_status_user":30}
350	93	1623667816135	{"id":93,"customer":"o1","vendor":"sdasdasd","status":"REJECTED","message":null,"reason":null,"change_status_date":1623667816133,"change_status_company":"o1","change_status_user":52}
351	93	1623667830537	{"id":93,"customer":"o1","vendor":"sdasdasd","status":"SENT","message":"I am interested in cooperation with your company.","reason":null,"change_status_date":1623667830535,"change_status_company":"o1","change_status_user":52}
352	95	1623669172695	{"id":95,"customer":"o1","vendor":"107386525","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623669172564,"change_status_company":"o1","change_status_user":52}
353	95	1623669310919	{"id":95,"customer":"o1","vendor":"107386525","status":"REJECTED","message":null,"reason":null,"change_status_date":1623669310905,"change_status_company":"o1","change_status_user":52}
354	95	1623669334088	{"id":95,"customer":"o1","vendor":"107386525","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623669334084,"change_status_company":"o1","change_status_user":52}
355	96	1623670106995	{"id":96,"customer":"Vautotest","vendor":"vendautotest","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623670106906,"change_status_company":"vendautotest","change_status_user":145}
356	96	1623670514529	{"id":96,"customer":"Vautotest","vendor":"vendautotest","status":"REJECTED","message":null,"reason":null,"change_status_date":1623670514527,"change_status_company":"vendautotest","change_status_user":145}
357	96	1623670525925	{"id":96,"customer":"Vautotest","vendor":"vendautotest","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623670525893,"change_status_company":"vendautotest","change_status_user":145}
358	96	1623670530912	{"id":96,"customer":"Vautotest","vendor":"vendautotest","status":"REJECTED","message":null,"reason":null,"change_status_date":1623670530861,"change_status_company":"vendautotest","change_status_user":145}
359	96	1623670584059	{"id":96,"customer":"Vautotest","vendor":"vendautotest","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623670584056,"change_status_company":"vendautotest","change_status_user":145}
360	96	1623670589504	{"id":96,"customer":"Vautotest","vendor":"vendautotest","status":"REJECTED","message":null,"reason":null,"change_status_date":1623670589500,"change_status_company":"vendautotest","change_status_user":145}
361	96	1623674129326	{"id":96,"customer":"Vautotest","vendor":"vendautotest","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623674129323,"change_status_company":"vendautotest","change_status_user":145}
362	96	1623674135847	{"id":96,"customer":"Vautotest","vendor":"vendautotest","status":"REJECTED","message":null,"reason":null,"change_status_date":1623674135843,"change_status_company":"vendautotest","change_status_user":145}
363	96	1623674175100	{"id":96,"customer":"Vautotest","vendor":"vendautotest","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623674175093,"change_status_company":"vendautotest","change_status_user":145}
364	96	1623674218912	{"id":96,"customer":"Vautotest","vendor":"vendautotest","status":"REJECTED","message":null,"reason":null,"change_status_date":1623674218910,"change_status_company":"vendautotest","change_status_user":145}
365	80	1623674464266	{"id":80,"customer":"custautotest","vendor":"vendautotest","status":"DISCONNECTED","message":null,"reason":null,"change_status_date":1623674464263,"change_status_company":"vendautotest","change_status_user":145}
366	80	1623674469203	{"id":80,"customer":"custautotest","vendor":"vendautotest","status":"SENT","message":"Я заинтересован в сотрудничестве с вашей компанией.","reason":null,"change_status_date":1623674469196,"change_status_company":"vendautotest","change_status_user":145}
367	80	1623674551303	{"id":80,"customer":"custautotest","vendor":"vendautotest","status":"CONNECTED","message":null,"reason":null,"change_status_date":1623674551298,"change_status_company":"custautotest","change_status_user":146}
\.


--
-- Data for Name: connections; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.connections (id, type, object, sender, recipient, status, comment, reject_reason, create_date, create_user, create_company, processing_date, processing_user, processing_company) FROM stdin;
1	stands	2	testCustVendID	testVendCustID	REJECTED	requestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestr	Reason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for rejectionReason for r	1614751865745	82	testCustVendID	1614751921454	78	testVendCustID
2	stands	2	testCustVendID	testVendCustID	APPROVED	requestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequest	\N	1614752006020	82	testCustVendID	1614752050594	78	testVendCustID
3	stands	10	r5	v5	APPROVED	комментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкоммен	\N	1614761170131	6	r5	1614761505758	31	v5
4	stands	19	r5	v5	APPROVED	\N	\N	1615452504695	6	r5	1615452514326	31	v5
5	stands	21	r5	v5	REJECTED	ячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсыва	ячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсыва	1616657099383	6	r5	1616657125737	31	v5
6	stands	21	r5	v5	APPROVED	\N	\N	1616657138385	6	r5	1616657151347	31	v5
7	stands	16	o20	testVendCustID	REJECTED	\N	\N	1616666610504	71	o20	1616666628648	78	testVendCustID
8	stands	16	o20	testVendCustID	APPROVED	\N	\N	1616666647121	71	o20	1616666657000	78	testVendCustID
9	stands	19	r5	v5	REJECTED	\N	\N	1617008533614	6	r5	1617008545146	31	v5
10	stands	19	r5	v5	APPROVED	\N	\N	1617008559938	6	r5	1617008572944	31	v5
11	stands	21	r5	v5	APPROVED	\N	\N	1617096174321	6	r5	1617096222785	31	v5
13	stands	21	r5	v5	REJECTED	\N	\N	1617096322318	6	r5	1617096358305	31	v5
12	stands	21	r5	v5	APPROVED	\N	\N	1617096322072	6	r5	1617096362989	31	v5
14	stands	21	r5	v5	APPROVED	\N	\N	1617097098671	6	r5	1617097120409	31	v5
15	stands	21	r5	v5	APPROVED	\N	\N	1617097187979	6	r5	1617097194880	31	v5
17	stands	19	r5	v5	APPROVED	\N	\N	1617100869815	6	r5	1617100923736	31	v5
16	stands	21	r5	v5	APPROVED	\N	\N	1617100520576	6	r5	1617180673102	31	v5
18	stands	44	r5	v5	APPROVED	\N	\N	1617180750089	6	r5	1617180774096	31	v5
19	stands	390	r5	v5	APPROVED	\N	\N	1619762170666	6	r5	1619762184439	31	v5
20	stands	619	r4	v4	APPROVED	цйуйцуйцу	\N	1622213471639	5	r4	1622213543205	30	v4
21	stands	619	r4	v4	APPROVED	\N	\N	1622213588860	5	r4	1622213600386	30	v4
22	stands	619	r4	v4	APPROVED	\N	\N	1622213634912	5	r4	1622213650429	30	v4
23	stands	619	r4	v4	APPROVED	\N	\N	1622213696683	5	r4	1622213726905	30	v4
24	stands	619	AIM123	v4	APPROVED	\N	\N	1622213716744	149	AIM123	1622213726905	30	v4
25	stands	619	AIM123	v4	REJECTED	\N	\N	1622213968908	149	AIM123	1622213979669	30	v4
26	stands	619	AIM123	v4	REJECTED	\N	цоацаиывьтмиывтьмиывьтм ч ьтываиьтывм чтывиьтаиывтьаиывтьаиывтьаиывтЬАИЫТЬВМИ ЧСМЧСЧ ОВИАЛОЙ42342343242343211456432 1ФЫ23А3В2ЫАЫВ32М1Ы32М1 ВЫА21ЫВ23А1ЫВ32М 23ЫАВ1Ы23М1 Ы23В1 2ЫА1ВЫ23А1ЫВ23М1 2А1ЦУ231АК3ЦУ2КА321М ФЫ21В23Ы1АЫВ23А1ЫВ32 23ВА1ЫВ32А1Ы32А1ЦУ32ЕК1432КУПИ 13ЫА1ЫВ32А1ЦУ32К1433Е132И1 В32А1ЫВ32А1ЦУ32П13Н145НКЕРП ЦУ31ЦУЕ23УК1П23УК1П2313236143256Е231 ЫВПВА2П31ВА32Р1 ЦУ23Е1КУ32Е1УК233345135УКП2АВ1ВА23Р13 АВП231ВА32П1ВА32П1К2У3Е14  АВПАВПВАПВАПВАПВАП ЫВАЦУКАЦАЫВАЫВПВАПРПАВРАПРОНЕГЕНГЕКГЕКЕЦ534534534ЫВАЫВ\n	1622213998913	149	AIM123	1622214170340	30	v4
27	stands	619	AIM123	v4	REJECTED	\N	\N	1622214243901	149	AIM123	1622214271654	30	v4
28	stands	619	r4	v4	REJECTED	\N	\N	1622214259256	5	r4	1622214271654	30	v4
29	stands	240	r6	v5	SENT	\N	\N	1622278052808	7	r6	\N	\N	\N
30	stands	633	o1	vendorinc	APPROVED	987879	\N	1622280815464	52	o1	1622280850556	172	vendorinc
31	stands	633	o1	vendorinc	REJECTED	\N	9898989898	1622280967734	52	o1	1622281184958	172	vendorinc
32	stands	633	o1	vendorinc	APPROVED	98989898	\N	1622281212516	52	o1	1622281280504	172	vendorinc
33	stands	318	r6	v1	SENT	\N	\N	1622283937631	7	r6	\N	\N	\N
34	stands	639	r6	v5	SENT	\N	\N	1622284875320	7	r6	\N	\N	\N
35	stands	240	r4	v5	APPROVED	\N	\N	1622287478282	5	r4	1622287494885	31	v5
36	stands	639	r2	v5	SENT	\N	\N	1622447434598	3	r2	\N	\N	\N
37	stands	318	r17	v1	SENT	\N	\N	1622453616275	18	r17	\N	\N	\N
\.


--
-- Data for Name: connections_versions; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.connections_versions (id, connection_id, time_stamp, data) FROM stdin;
1	1	1614751865793	{"id":1,"type":"stands","object":2,"sender":"testCustVendID","recipient":"testVendCustID","status":"SENT","comment":"requestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestr","reject_reason":null,"create_date":1614751865745,"create_user":82,"create_company":"testCustVendID","processing_date":null,"processing_user":null,"processing_company":null}
2	1	1614751921471	{"id":1,"type":"stands","object":2,"sender":"testCustVendID","recipient":"testVendCustID","status":"SENT","comment":"requestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestr","reject_reason":null,"create_date":1614751865745,"create_user":82,"create_company":"testCustVendID","processing_date":null,"processing_user":null,"processing_company":null}
3	2	1614752006036	{"id":2,"type":"stands","object":2,"sender":"testCustVendID","recipient":"testVendCustID","status":"SENT","comment":"requestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequest","reject_reason":null,"create_date":1614752006020,"create_user":82,"create_company":"testCustVendID","processing_date":null,"processing_user":null,"processing_company":null}
4	2	1614752050608	{"id":2,"type":"stands","object":2,"sender":"testCustVendID","recipient":"testVendCustID","status":"SENT","comment":"requestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequestrequest","reject_reason":null,"create_date":1614752006020,"create_user":82,"create_company":"testCustVendID","processing_date":null,"processing_user":null,"processing_company":null}
5	3	1614761170144	{"id":3,"type":"stands","object":10,"sender":"r5","recipient":"v5","status":"SENT","comment":"комментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкоммен","reject_reason":null,"create_date":1614761170131,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
6	3	1614761505768	{"id":3,"type":"stands","object":10,"sender":"r5","recipient":"v5","status":"SENT","comment":"комментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкомментарийкоммен","reject_reason":null,"create_date":1614761170131,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
7	4	1615452504855	{"id":4,"type":"stands","object":19,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1615452504695,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
8	4	1615452514322	{"id":4,"type":"stands","object":19,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1615452504695,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
9	5	1616657099463	{"id":5,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":"ячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсыва","reject_reason":null,"create_date":1616657099383,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
32	16	1617100520601	{"id":16,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617100520576,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
10	5	1616657125746	{"id":5,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":"ячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсывафвфывфывячсячсячсячсячсыва","reject_reason":null,"create_date":1616657099383,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
11	6	1616657138388	{"id":6,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1616657138385,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
12	6	1616657151352	{"id":6,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1616657138385,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
13	7	1616666610510	{"id":7,"type":"stands","object":16,"sender":"o20","recipient":"testVendCustID","status":"SENT","comment":null,"reject_reason":null,"create_date":1616666610504,"create_user":71,"create_company":"o20","processing_date":null,"processing_user":null,"processing_company":null}
14	7	1616666628660	{"id":7,"type":"stands","object":16,"sender":"o20","recipient":"testVendCustID","status":"SENT","comment":null,"reject_reason":null,"create_date":1616666610504,"create_user":71,"create_company":"o20","processing_date":null,"processing_user":null,"processing_company":null}
15	8	1616666647130	{"id":8,"type":"stands","object":16,"sender":"o20","recipient":"testVendCustID","status":"SENT","comment":null,"reject_reason":null,"create_date":1616666647121,"create_user":71,"create_company":"o20","processing_date":null,"processing_user":null,"processing_company":null}
16	8	1616666657005	{"id":8,"type":"stands","object":16,"sender":"o20","recipient":"testVendCustID","status":"SENT","comment":null,"reject_reason":null,"create_date":1616666647121,"create_user":71,"create_company":"o20","processing_date":null,"processing_user":null,"processing_company":null}
17	9	1617008533730	{"id":9,"type":"stands","object":19,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617008533614,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
18	9	1617008545150	{"id":9,"type":"stands","object":19,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617008533614,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
19	10	1617008559941	{"id":10,"type":"stands","object":19,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617008559938,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
20	10	1617008572949	{"id":10,"type":"stands","object":19,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617008559938,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
21	11	1617096174456	{"id":11,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617096174321,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
22	11	1617096222780	{"id":11,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617096174321,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
23	12	1617096322094	{"id":12,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617096322072,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
24	13	1617096322321	{"id":13,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617096322318,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
25	13	1617096358295	{"id":13,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617096322318,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
26	12	1617096358295	{"id":12,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617096322072,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
27	12	1617096363002	{"id":12,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"REJECTED","comment":null,"reject_reason":null,"create_date":1617096322072,"create_user":6,"create_company":"r5","processing_date":1617096358305,"processing_user":31,"processing_company":"v5"}
28	14	1617097098692	{"id":14,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617097098671,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
29	14	1617097120414	{"id":14,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617097098671,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
30	15	1617097187992	{"id":15,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617097187979,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
31	15	1617097194884	{"id":15,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617097187979,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
33	17	1617100869897	{"id":17,"type":"stands","object":19,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617100869815,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
34	17	1617100923742	{"id":17,"type":"stands","object":19,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617100869815,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
35	16	1617180673053	{"id":16,"type":"stands","object":21,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617100520576,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
36	18	1617180750095	{"id":18,"type":"stands","object":44,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617180750089,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
37	18	1617180774122	{"id":18,"type":"stands","object":44,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1617180750089,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
38	19	1619762170724	{"id":19,"type":"stands","object":390,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1619762170666,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
39	19	1619762184434	{"id":19,"type":"stands","object":390,"sender":"r5","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1619762170666,"create_user":6,"create_company":"r5","processing_date":null,"processing_user":null,"processing_company":null}
40	20	1622213472042	{"id":20,"type":"stands","object":619,"sender":"r4","recipient":"v4","status":"SENT","comment":"цйуйцуйцу","reject_reason":null,"create_date":1622213471639,"create_user":5,"create_company":"r4","processing_date":null,"processing_user":null,"processing_company":null}
41	20	1622213538337	{"id":20,"type":"stands","object":619,"sender":"r4","recipient":"v4","status":"SENT","comment":"цйуйцуйцу","reject_reason":null,"create_date":1622213471639,"create_user":5,"create_company":"r4","processing_date":null,"processing_user":null,"processing_company":null}
42	20	1622213543209	{"id":20,"type":"stands","object":619,"sender":"r4","recipient":"v4","status":"APPROVED","comment":"цйуйцуйцу","reject_reason":null,"create_date":1622213471639,"create_user":5,"create_company":"r4","processing_date":1622213538346,"processing_user":30,"processing_company":"v4"}
43	21	1622213588867	{"id":21,"type":"stands","object":619,"sender":"r4","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622213588860,"create_user":5,"create_company":"r4","processing_date":null,"processing_user":null,"processing_company":null}
44	21	1622213600397	{"id":21,"type":"stands","object":619,"sender":"r4","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622213588860,"create_user":5,"create_company":"r4","processing_date":null,"processing_user":null,"processing_company":null}
45	22	1622213634924	{"id":22,"type":"stands","object":619,"sender":"r4","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622213634912,"create_user":5,"create_company":"r4","processing_date":null,"processing_user":null,"processing_company":null}
46	22	1622213650420	{"id":22,"type":"stands","object":619,"sender":"r4","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622213634912,"create_user":5,"create_company":"r4","processing_date":null,"processing_user":null,"processing_company":null}
47	23	1622213696689	{"id":23,"type":"stands","object":619,"sender":"r4","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622213696683,"create_user":5,"create_company":"r4","processing_date":null,"processing_user":null,"processing_company":null}
48	24	1622213716749	{"id":24,"type":"stands","object":619,"sender":"AIM123","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622213716744,"create_user":149,"create_company":"AIM123","processing_date":null,"processing_user":null,"processing_company":null}
49	24	1622213726842	{"id":24,"type":"stands","object":619,"sender":"AIM123","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622213716744,"create_user":149,"create_company":"AIM123","processing_date":null,"processing_user":null,"processing_company":null}
50	23	1622213726842	{"id":23,"type":"stands","object":619,"sender":"r4","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622213696683,"create_user":5,"create_company":"r4","processing_date":null,"processing_user":null,"processing_company":null}
51	25	1622213968919	{"id":25,"type":"stands","object":619,"sender":"AIM123","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622213968908,"create_user":149,"create_company":"AIM123","processing_date":null,"processing_user":null,"processing_company":null}
52	25	1622213979673	{"id":25,"type":"stands","object":619,"sender":"AIM123","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622213968908,"create_user":149,"create_company":"AIM123","processing_date":null,"processing_user":null,"processing_company":null}
53	26	1622213998926	{"id":26,"type":"stands","object":619,"sender":"AIM123","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622213998913,"create_user":149,"create_company":"AIM123","processing_date":null,"processing_user":null,"processing_company":null}
54	26	1622214170348	{"id":26,"type":"stands","object":619,"sender":"AIM123","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622213998913,"create_user":149,"create_company":"AIM123","processing_date":null,"processing_user":null,"processing_company":null}
55	27	1622214243910	{"id":27,"type":"stands","object":619,"sender":"AIM123","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622214243901,"create_user":149,"create_company":"AIM123","processing_date":null,"processing_user":null,"processing_company":null}
56	28	1622214259264	{"id":28,"type":"stands","object":619,"sender":"r4","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622214259256,"create_user":5,"create_company":"r4","processing_date":null,"processing_user":null,"processing_company":null}
57	28	1622214271647	{"id":28,"type":"stands","object":619,"sender":"r4","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622214259256,"create_user":5,"create_company":"r4","processing_date":null,"processing_user":null,"processing_company":null}
58	27	1622214271647	{"id":27,"type":"stands","object":619,"sender":"AIM123","recipient":"v4","status":"SENT","comment":null,"reject_reason":null,"create_date":1622214243901,"create_user":149,"create_company":"AIM123","processing_date":null,"processing_user":null,"processing_company":null}
59	29	1622278052839	{"id":29,"type":"stands","object":240,"sender":"r6","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1622278052808,"create_user":7,"create_company":"r6","processing_date":null,"processing_user":null,"processing_company":null}
60	30	1622280815553	{"id":30,"type":"stands","object":633,"sender":"o1","recipient":"vendorinc","status":"SENT","comment":"987879","reject_reason":null,"create_date":1622280815464,"create_user":52,"create_company":"o1","processing_date":null,"processing_user":null,"processing_company":null}
61	30	1622280850549	{"id":30,"type":"stands","object":633,"sender":"o1","recipient":"vendorinc","status":"SENT","comment":"987879","reject_reason":null,"create_date":1622280815464,"create_user":52,"create_company":"o1","processing_date":null,"processing_user":null,"processing_company":null}
62	31	1622280967740	{"id":31,"type":"stands","object":633,"sender":"o1","recipient":"vendorinc","status":"SENT","comment":null,"reject_reason":null,"create_date":1622280967734,"create_user":52,"create_company":"o1","processing_date":null,"processing_user":null,"processing_company":null}
63	31	1622281184978	{"id":31,"type":"stands","object":633,"sender":"o1","recipient":"vendorinc","status":"SENT","comment":null,"reject_reason":null,"create_date":1622280967734,"create_user":52,"create_company":"o1","processing_date":null,"processing_user":null,"processing_company":null}
64	32	1622281212525	{"id":32,"type":"stands","object":633,"sender":"o1","recipient":"vendorinc","status":"SENT","comment":"98989898","reject_reason":null,"create_date":1622281212516,"create_user":52,"create_company":"o1","processing_date":null,"processing_user":null,"processing_company":null}
65	32	1622281280512	{"id":32,"type":"stands","object":633,"sender":"o1","recipient":"vendorinc","status":"SENT","comment":"98989898","reject_reason":null,"create_date":1622281212516,"create_user":52,"create_company":"o1","processing_date":null,"processing_user":null,"processing_company":null}
66	33	1622283937651	{"id":33,"type":"stands","object":318,"sender":"r6","recipient":"v1","status":"SENT","comment":null,"reject_reason":null,"create_date":1622283937631,"create_user":7,"create_company":"r6","processing_date":null,"processing_user":null,"processing_company":null}
67	34	1622284875335	{"id":34,"type":"stands","object":639,"sender":"r6","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1622284875320,"create_user":7,"create_company":"r6","processing_date":null,"processing_user":null,"processing_company":null}
68	35	1622287478320	{"id":35,"type":"stands","object":240,"sender":"r4","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1622287478282,"create_user":5,"create_company":"r4","processing_date":null,"processing_user":null,"processing_company":null}
69	35	1622287494894	{"id":35,"type":"stands","object":240,"sender":"r4","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1622287478282,"create_user":5,"create_company":"r4","processing_date":null,"processing_user":null,"processing_company":null}
70	36	1622447434766	{"id":36,"type":"stands","object":639,"sender":"r2","recipient":"v5","status":"SENT","comment":null,"reject_reason":null,"create_date":1622447434598,"create_user":3,"create_company":"r2","processing_date":null,"processing_user":null,"processing_company":null}
71	37	1622453616303	{"id":37,"type":"stands","object":318,"sender":"r17","recipient":"v1","status":"SENT","comment":null,"reject_reason":null,"create_date":1622453616275,"create_user":18,"create_company":"r17","processing_date":null,"processing_user":null,"processing_company":null}
\.


--
-- Name: company_connections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.company_connections_id_seq', 96, true);


--
-- Name: company_connections_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.company_connections_versions_id_seq', 367, true);


--
-- Name: connections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.connections_id_seq', 37, true);


--
-- Name: connections_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.connections_versions_id_seq', 71, true);


--
-- Name: company_connections company_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_connections
    ADD CONSTRAINT company_connections_pkey PRIMARY KEY (id);


--
-- Name: company_connections_versions company_connections_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_connections_versions
    ADD CONSTRAINT company_connections_versions_pkey PRIMARY KEY (id);


--
-- Name: connections connections_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT connections_pkey PRIMARY KEY (id);


--
-- Name: connections_versions connections_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.connections_versions
    ADD CONSTRAINT connections_versions_pkey PRIMARY KEY (id);


--
-- Name: connections_create_date_desc_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX connections_create_date_desc_index ON public.connections USING btree (create_date DESC NULLS LAST);


--
-- Name: connections_id_idx; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX connections_id_idx ON public.connections USING btree (id);


--
-- Name: connections_processing_date_desc_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX connections_processing_date_desc_index ON public.connections USING btree (processing_date DESC);


--
-- Name: connections_status_idx; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX connections_status_idx ON public.connections USING btree (status);


--
-- PostgreSQL database dump complete
--

